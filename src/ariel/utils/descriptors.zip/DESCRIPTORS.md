## 1. **Size (S)**
**Definition:**
Measures how much of the robot’s bounding-box volume is filled with modules.
It is computed as the ratio between the number of modules and the total volume of the minimal bounding box enclosing the robot.
This captures overall morphological compactness and physical occupied space.

**Formula:**
`S = m / m_max`
where `m` is the number of modules and `m_max` is the bounding-box volume.

---

## 2. **Branching (B)**
**Definition:**
Quantifies how many modules (core and bricks) have all of their attachment faces occupied by other modules, normalized by the maximum number that *could* be filled given the available modules.
A high branching value indicates dense, tree-like morphologies with many connection points saturated.

**Formula:**
`B = b / b_max`
where `b` is the number of filled bricks and filled core, and `b_max` is the theoretical maximum.

---

## 3. **Limbs (L)**
**Definition:**
Measures how many modules act as *endpoints* or *leaf nodes*, i.e., modules connected to only a single neighbor.
Larger values correspond to morphologies with many protruding limbs or extremities.

**Formula:**
`L = l / l_max`
where `l` is the number of single-neighbor modules and `l_max` is the maximum possible given the module count.

---

## 4. **Extensiveness (E)**
**Definition:**
Measures how many modules form linear chains within limbs—i.e., bricks and hinges that connect to exactly two neighbors.
Higher extensiveness indicates long limbs made of multi-segment chains.

**Formula:**
`E = e / e_max`
where `e` is the number of double-neighbor bricks and hinges, and `e_max` is the maximal possible number for the given morphology.

---

## 5. **Symmetry (C)**
**Definition:**
Quantifies how symmetric the morphology is with respect to three anatomical planes: XY, XZ, and YZ.
Symmetry is computed by comparing module pairs mirrored across each plane.
The final symmetry score is the *maximum* symmetry observed among the three planes.

**Formula:**
`C = max(sym_xy, sym_xz, sym_yz)`
where each `sym_*` is the proportion of mirrored module pairs with matching types.

---

## 6. **Joints (J)**
**Definition:**
Counts how many active hinges (joints) the robot has relative to the theoretical maximum (i.e., one hinge per adjacency edge).
A larger value indicates higher potential mobility and actuation complexity.

**Formula:**
`J = j / j_max`
where `j` is the number of active hinges and `j_max = num_modules - 1`.

---

## Optional (2D Robots Only): **Proportion (P)**
**Definition:**
Used only for strictly planar (2D) robots.
Measures the aspect ratio of the bounding box in the 2D plane and captures shape elongation.

**Formula:**
`P = min(width, depth) / max(width, depth)`
